import unittest
import requests

class Testlogin(unittest.TestCase):
    url = 'http://192.168.9.212:8620/gateway/login'

    # def test_login_normal(self, ky):
    #     param = {"key": "{}".format(ky)}
    #
    #     res = requests.get(url=self.url, params=param)
    #     self.assertIn("成功", res.text)
    #     # text = res.text
    #     # return text
    #
    # def test_login_errorkey(self, ky):
    #     param = {"key": "{}".format(ky)}
    #
    #     res = requests.get(url=self.url, params=param)
    #     self.assertIn("用户名或密码错误", res.text)

    def setUp(self):
        print("登录测试用例开始")

    def tearDown(self):
        print("登录测试用例完成")

    def test_login_normal(self):
        param = {"key": "1IEuD18Z1ug=|k6NQq3efZgg="}

        res = requests.get(url=self.url, params=param)
        self.assertIn("成功", res.text)
        text = res.text
        return text

    def test_login_errorkey(self):
        param = {"key": "1IEuD18Z1ug=|43uuS2GwxAtAfhWo8r1NzA=="}

        res = requests.get(url=self.url, params=param)
        self.assertIn("用户名或密码错误", res.text)

    def test_login_null(self):
        param = {"key": ""}

        res = requests.get(url=self.url, params=param)
        self.assertIn("参数不能为空", res.text)

    def test_login_cha(self):
        param = {"key": "密码"}
        res = requests.get(url=self.url, params=param)
        self.assertIn("参数错误", res.text)

    if __name__ == '__main__':
        unittest.main(verbosity=2)




