import unittest
from HTMLTestReportCN import  HTMLTestRunner

#  运行目录下所有test_开头的文件下的用例
suite = unittest.defaultTestLoader.discover("./")

f = open("report.html", 'wb')
HTMLTestRunner(stream=f, title="api test", description="测试描述", tester="test01").run(suite)